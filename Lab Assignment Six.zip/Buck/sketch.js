var x = [];
function setup() {
  createCanvas(400, 400);
  
   for (var i = 0; i < 5;  i++) {
    x[i]=0;
  print(x.length);
   }
}

function draw() {
  background(60);
  x[5]=mouseX;
  
  fill('darkorange');
  circle(x[5],200,50);
  fill('green');
  
let xcord;
  xcord = x[5]-7;
  
  rect(xcord,160,13,25);
  
  fill('purple');
  textSize(32);
  text('Happy Halloween!', 75,100);
  
}