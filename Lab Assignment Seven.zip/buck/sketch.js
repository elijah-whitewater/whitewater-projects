let x=0;
function setup() {
  createCanvas(400, 400);
  background(0,110,255);
  let x=0;
  for (i=0;i<10;i++) {
  drawShape();
    moveCircle();
    scale(1.06, 1 , 1);
    angleMode(DEGREES);
    rotate(0.29);
    print(i);
  }
}

function drawShape() {
circle (0,0,50);
}

function moveCircle(){
translate (x,0);
x=40
//x=x+50;  
}

function draw(){
  stroke('orange')
  push();
fill('yellow');
  stroke('yellow');
circle (75, 110, 75);
  line(75, 45, 75 , 180)
  pop();
  line (10,110,140,110);
}