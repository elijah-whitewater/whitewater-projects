let x=0;
let man;
let grass;


function preload() {
  man = loadImage('/assets/osrsman.jpg');
  grass = loadImage('/assets/grass.jpg')
  rain = loadImage('/assets/rain.gif')
}  
  
function setup() {
  createCanvas(400, 400);
}
  
function drawShape() {
  fill('gray')
circle (0,0,50);
}

function moveCircle(){
translate (x,0);
x=40
//x=x+50;  
}



function draw() {
 background(255);
 imageMode(CENTER); 
  textFont('Gotham');
  textAlign(CENTER);
  let s = 'go home, its raining';
  stroke(0.5);
  fill('black');
  text(s, 200, 60, 0, 100);
  
  push();
  scale(0.1);
  image(grass, 600, 3000);
  pop();
  
  push();
scale(4);
image(rain, 0, 0);
pop();

  image(man, mouseX, 275);
  
  
  for (i=0;i<10;i++) {
  drawShape();
    moveCircle();
    scale(1.06, 1 , 1);
    angleMode(DEGREES);
    rotate(0.29);

  }

}